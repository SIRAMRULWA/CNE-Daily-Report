"""Shared API query helpers."""
